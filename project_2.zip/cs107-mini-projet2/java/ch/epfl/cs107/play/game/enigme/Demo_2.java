package ch.epfl.cs107.play.game.enigme;

import ch.epfl.cs107.play.game.actor.Actor;
import ch.epfl.cs107.play.game.areagame.AreaGame;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.enigme.actor.demo2.Demo2Player;
import ch.epfl.cs107.play.game.enigme.area.Demo_2.Demo2Area;
import ch.epfl.cs107.play.game.enigme.area.Demo_2.Room0;
import ch.epfl.cs107.play.game.enigme.area.Demo_2.Room1;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Window;

public class Demo_2 extends AreaGame {
	
	private Demo2Area a, b;
	private Demo2Player player;

	public int getFrameRate() {
		// TODO Auto-generated method stub
		return 24;
	}

	public String getTitle() {
		// TODO Auto-generated method stub
		return "Demo_2";
	}

	public boolean begin(Window window, FileSystem fileSystem) {
		// TODO implements me #PROJECT #TUTO
			super.begin(window, fileSystem);
			a = new Room1();
			b = new Room0();
			addArea(a);
			addArea(b);
			setCurrentArea("LevelSelector", false);
			player = new Demo2Player(b, new DiscreteCoordinates(5, 5));
			player.enterArea(getCurrentArea(), new DiscreteCoordinates(5, 5));
			getCurrentArea().setViewCandidate(player);
			return true;
	}
	
	@Override
    public void update(float deltaTime) {
		if (player.isADoor == true && getCurrentArea().getTitle() == "LevelSelector") {
			player.leaveArea(getCurrentArea());
			setCurrentArea("Level1", false);
			player.enterArea(getCurrentArea(), new DiscreteCoordinates(5, 2));
		} else if (player.isADoor == true && getCurrentArea().getTitle() == "Level1") {
			player.leaveArea(getCurrentArea());
			setCurrentArea("LevelSelector", false);
			player.enterArea(getCurrentArea(), new DiscreteCoordinates(5, 5));
		}
        super.update(deltaTime);
    }

}
