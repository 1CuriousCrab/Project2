package ch.epfl.cs107.play.game.areagame.actor;

import java.util.LinkedList;
import java.util.List;

import com.sun.prism.image.Coords;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.math.Vector;


/**
 * MovableAreaEntity are AreaEntity able to move on a grid
 */
public abstract class MovableAreaEntity extends AreaEntity {

    // TODO implements me #PROJECT #TUTO
	private boolean isMoving ;
	private int framesForCurrentMove ;
	private DiscreteCoordinates targetMainCellCoordinates ;
	
    /**
     * Default MovableAreaEntity constructor
     * @param area (Area): Owner area. Not null
     * @param position (Coordinate): Initial position of the entity. Not null
     * @param orientation (Orientation): Initial orientation of the entity. Not null
     */
    public MovableAreaEntity(Area area, Orientation orientation, DiscreteCoordinates position) {
        super(area, orientation, position);
        // TODO implements me #PROJECT #TUTO
        resetMotion();
    }
    
    @Override
    protected void setOrientation(Orientation orientation) {
    	if (!isMoving) {
    		super.setOrientation(orientation);
    	}
    }

    /**
     * Initialize or reset the current motion information
     */
    protected void resetMotion(){
        // TODO implements me #PROJECT #TUTO
    	framesForCurrentMove = 0;
    	isMoving = false;
    	targetMainCellCoordinates = getCurrentMainCellCoordinates();
    }

    /**
     * 
     * @param frameForMove (int): number of frames used for simulating motion
     * @return (boolean): returns true if motion can occur
     */
  
    protected  boolean move(int framesForMove){
    	
        // TODO implements me #PROJECT #TUTO
    	if ((!isMoving || getCurrentMainCellCoordinates().equals(targetMainCellCoordinates))) {
    		
    		if(getOwnerArea().enterAreaCells(this, getEnteringCells()) && getOwnerArea().leaveAreaCells(this, getLeavingCells())) {
    			System.out.println("is working");
    			if (framesForMove < 1) {
    				framesForCurrentMove = 1;
    			} else {
    				framesForCurrentMove = framesForMove;
    			}
    			Vector orientation = getOrientation();
    			targetMainCellCoordinates = getCurrentMainCellCoordinates().jump(orientation);
    			isMoving = true;
    			return true;
    		
        		}
    		else {
            	System.out.println("Le deplacement est impossible, c'est dommage, allez vous brosser les dents");
            	return false;
            		
            	}
    		}
    	else {
    		System.out.println("isnt working");
    		return true;
    		
    	}
		
    }


    /// MovableAreaEntity implements Actor

    @Override
    public void update(float deltaTime) {
        // TODO implements me #PROJECT #TUTO
    	if (isMoving && !getCurrentMainCellCoordinates().equals(targetMainCellCoordinates)) {
    		Vector distance = getOrientation();
    		distance = distance.mul(1.0f / framesForCurrentMove) ;
    		setCurrentPosition(getPosition().add(distance)) ;
    	} else {
    		resetMotion();
    	} 
    	
    }
    
    public void coordinates() {
    	System.out.println("target ="+targetMainCellCoordinates);
    	DiscreteCoordinates checker = getCurrentMainCellCoordinates();
    	System.out.println("position="+checker);
    	if(isMoving) {
    		System.out.println("je bouges");
    	}
    }

    /// Implements Positionable

    @Override
    public Vector getVelocity() {
        // TODO implements me #PROJECT #TUTO
        // the velocity must be computed as the orientation vector (getOrientation().toVector() mutiplied by 
    	// framesForCurrentMove
    	float x = getOrientation().getX() * (float) framesForCurrentMove;
    	float y = getOrientation().getY() * (float) framesForCurrentMove;
        return new Vector(x, y);
    }
    
    protected final List <DiscreteCoordinates > getLeavingCells() {
    	return getCurrentCells();
    }
    
    
    protected final List <DiscreteCoordinates > getEnteringCells() {
    	List <DiscreteCoordinates>  position = getLeavingCells();
    	List <DiscreteCoordinates> enteringCells = new LinkedList<>();
    	for(int i = 0; i < position.size(); ++i) {
    		enteringCells.add(position.get(i).jump(getOrientation()));
    	}
    	return enteringCells;
    }
}
