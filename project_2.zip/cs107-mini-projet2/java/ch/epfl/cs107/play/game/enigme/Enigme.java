package ch.epfl.cs107.play.game.enigme;

import ch.epfl.cs107.play.game.areagame.AreaGame;
import ch.epfl.cs107.play.game.enigme.actor.EnigmePlayer;
import ch.epfl.cs107.play.game.enigme.actor.demo2.Demo2Player;
import ch.epfl.cs107.play.game.enigme.area.EnigmeArea;
import ch.epfl.cs107.play.game.enigme.area.Level1;
import ch.epfl.cs107.play.game.enigme.area.Level2;
import ch.epfl.cs107.play.game.enigme.area.Level3;
import ch.epfl.cs107.play.game.enigme.area.LevelSelector;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Window;


/**
 * Enigme Game is a concept of Game derived for AreaGame. It introduces the notion of Player
 * When initializing the player is added to the current area
 */
public class Enigme extends AreaGame {

    /// The player is a concept of RPG games
    // TODO implements me #PROJECT

	private EnigmeArea a, b, c, d;
	private EnigmePlayer player;
	
    /// Enigme implements Playable

    @Override
    public String getTitle() {
        return "Enigme";
    }

    @Override
    public boolean begin(Window window, FileSystem fileSystem) {
        // TODO implements me #PROJECT
    	super.begin(window, fileSystem);
    	a = new Level1();
		b = new Level2();
		c = new Level3();
		d = new LevelSelector();
		addArea(a);
		addArea(b);
		addArea(c);
		addArea(d);
		setCurrentArea("LevelSelector", false);
		player = new EnigmePlayer(getCurrentArea(), new DiscreteCoordinates(5, 5));
		d.registerActor(player);
		d.setViewCandidate(player);
        return true;
    }

    @Override
    public void update(float deltaTime) {
        // TODO implements me #PROJECT
    	super.update(deltaTime);
    	if (player.isPassingDoor) {
    		player.leaveArea(getCurrentArea());
    		setCurrentArea(player.passedDoor().getDestinationArea(), false);
    		player.enterArea(getCurrentArea(), player.passedDoor().getCoordinatesAtDestination());
    	}
    }


    @Override
    public int getFrameRate() {
        return 24;
    }
}
