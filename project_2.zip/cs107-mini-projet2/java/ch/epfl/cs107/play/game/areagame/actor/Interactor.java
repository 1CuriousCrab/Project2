package ch.epfl.cs107.play.game.areagame.actor;

import java.util.List;

import ch.epfl.cs107.play.math.DiscreteCoordinates;

/**
 * Models objects asking for interaction (i.e. can interact with some Interactable)
 * @see Interactable
 * This interface makes sense only in the "Area Context" with Actor contained into Area Cell
 */
public interface Interactor {

    // TODO implements me #PROJECT #TUTO
	//retourne les cellules occupees par l'objet
	List<DiscreteCoordinates> getCurrentCells() ;
	
	//retourne les cellules visibles par l'objet
	List<DiscreteCoordinates> getFieldOfViewCells();
	
	//indique s'il demande une interaction de contact
	boolean wantsCellInteraction();
	
	boolean wantsViewInteraction();
}
