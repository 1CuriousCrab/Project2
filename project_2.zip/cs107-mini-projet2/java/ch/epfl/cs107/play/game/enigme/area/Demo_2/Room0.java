package ch.epfl.cs107.play.game.enigme.area.Demo_2;


public class Room0 extends Demo2Area {
	public String getTitle( ) {
		return "LevelSelector";
	}
}
