package ch.epfl.cs107.play.game.enigme.actor.demo2;


import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.MovableAreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.game.enigme.Demo_2_Behavior;
import ch.epfl.cs107.play.game.enigme.Demo_2_Behavior.Demo2CellType;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Button;
import ch.epfl.cs107.play.window.Canvas;
import ch.epfl.cs107.play.window.Keyboard;

public class Demo2Player extends MovableAreaEntity {
	
	Sprite demo2Player;
	private final static int ANIMATION_DURATION = 8 ;
	public boolean isADoor = false;
	
	public Demo2Player(Area area , Orientation orientation , DiscreteCoordinates coordinates) {
		super(area, orientation, coordinates);
		demo2Player = new Sprite("ghost.1", 1, 1.f,this) ;
		
	}
	
	public Demo2Player(Area area , DiscreteCoordinates coordinates) {
		this(area, Orientation.DOWN, coordinates);
	}

	@Override
	public boolean takeCellSpace() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isViewInteractable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCellInteractable() {
		// TODO Auto-generated method stub
		return true;
	}
	
	@Override
	public List <DiscreteCoordinates > getCurrentCells() {
	return Collections.singletonList(getCurrentMainCellCoordinates()) ;
	}
	
	public void enterArea(Area area , DiscreteCoordinates position) {
		area.registerActor(this);
		this.setCurrentPosition(position.toVector());
		this.resetMotion();
	}
	
	public void leaveArea(Area area) {
		area.unregisterActor(this);
	}
	
	public void setSpecified(boolean value) {
		
	}
	
	@Override
	public void update(float deltaTime) {
		super.update(deltaTime);
		Keyboard keyboard = getOwnerArea().getKeyboard();
		Button left = keyboard.get(Keyboard.LEFT);
		Button right = keyboard.get(Keyboard.RIGHT);
		Button up = keyboard.get(Keyboard.UP);
		Button down = keyboard.get(Keyboard.DOWN);
		Button space = keyboard.get(Keyboard.SPACE);
		
		if (left.isDown()) {
			if (getRealOrientation().equals(Orientation.LEFT)) {
				move(ANIMATION_DURATION);
				
			} else {
				setOrientation(Orientation.LEFT);
			}
		}
		
		if (right.isDown()) {
			if (getRealOrientation().equals(Orientation.RIGHT)) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.RIGHT);
			}
		}
		
		if (up.isDown()) {
			if (getRealOrientation().equals(Orientation.UP)) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.UP);
			}
		}
		
		if (down.isDown()) {
			if (getRealOrientation().equals(Orientation.DOWN)) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.DOWN);
			}
		}
		
		if (space.isDown()) {
			coordinates();
		}
	}

	@Override
	public void draw(Canvas canvas) {
		// TODO Auto-generated method stub
		demo2Player.draw(canvas);
		
	}
	
	@Override
	public boolean move(int frameForMove) {
		//REFAIRE CODE PORTE
		Demo_2_Behavior a = (Demo_2_Behavior) getOwnerArea().getBehavior();
		if (a.getCurrentCellPosition(getCurrentMainCellCoordinates()).getType() == Demo2CellType.DOOR) {
			isADoor = true;
		}
		return super.move(frameForMove);
	}
	
}
