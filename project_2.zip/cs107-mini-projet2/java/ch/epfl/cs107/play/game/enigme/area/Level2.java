package ch.epfl.cs107.play.game.enigme.area;

import ch.epfl.cs107.play.game.enigme.area.EnigmeArea;

public class Level2 extends EnigmeArea {
	public String getTitle() {
		return "Level2";
	}
}

