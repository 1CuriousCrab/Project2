package ch.epfl.cs107.play.game.demo1;

import java.awt.Color;

import ch.epfl.cs107.play.game.Game;
import ch.epfl.cs107.play.game.actor.Actor;
import ch.epfl.cs107.play.game.actor.GraphicsEntity;
import ch.epfl.cs107.play.game.actor.ShapeGraphics;
import ch.epfl.cs107.play.game.actor.TextGraphics;
import ch.epfl.cs107.play.game.demo1.actor.MovingRock;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.math.Circle;
import ch.epfl.cs107.play.math.Transform;
import ch.epfl.cs107.play.math.Vector;
import ch.epfl.cs107.play.window.Button;
import ch.epfl.cs107.play.window.Keyboard;
import ch.epfl.cs107.play.window.Window;

public class Demo1 implements Game {
		private Actor actor1;
		private Actor actor2;
		private Window window ;
		private FileSystem fileSystem ;
		private final TextGraphics text2 = new TextGraphics("Bitches love Cannons", 0.04f, Color.RED);
		
		
		
		public String getTitle() {
			return "Demo1";
		}
		
		public int getFrameRate() {
			return 24;
		}
		
		public boolean begin(Window window, FileSystem fileSystem) {
			this.window = window;
			this.fileSystem = fileSystem;
			float radius = 0.2f;
			actor1 = new GraphicsEntity(Vector.ZERO , new ShapeGraphics(new Circle(radius), null, Color.RED, 0.005f)) ;
			actor2 = new MovingRock(new Vector(0.25f, 0.25f), "Oh there, We are in trouble...");
			
			return true;
		}
		
		public void end() {
			
		}
		
		public void update(float deltaTime) {
			actor1.draw(window);
			actor2.draw(window);
			Keyboard keyboard = window.getKeyboard() ;
			Button downArrow = keyboard.get(Keyboard.DOWN);
			if (downArrow.isDown()) {
				actor2.update(deltaTime);
			}
			Vector positionCircle = actor1.getPosition();
			Vector positionRock = actor2.getPosition();
			if (Math.sqrt(Math.pow(positionCircle.getX() - positionRock.getX(), 2) + Math.pow(positionCircle.getY() - positionRock.getY(), 2)) <= 0.2f) {
					text2.draw(window);
				}
		}
		
		
}
