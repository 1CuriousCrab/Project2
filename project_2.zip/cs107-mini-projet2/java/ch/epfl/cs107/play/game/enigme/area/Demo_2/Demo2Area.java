package ch.epfl.cs107.play.game.enigme.area.Demo_2;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Background;
import ch.epfl.cs107.play.game.enigme.Demo_2_Behavior;
import ch.epfl.cs107.play.io.FileSystem;
import ch.epfl.cs107.play.window.Window;

public class Demo2Area extends Area {
	
	public boolean begin(Window window, FileSystem fileSystem) {
		super.begin(window, fileSystem);
		setBehavior(new Demo_2_Behavior(window , getTitle())) ;
		if (registerActor(new Background(this))) {
			return true;
		} else {
			return false;
		}
	}
	
	public float getCameraScaleFactor() {
		return 12f;
	}
	
	public String getTitle() {
		return null;
	}
	
	
}
