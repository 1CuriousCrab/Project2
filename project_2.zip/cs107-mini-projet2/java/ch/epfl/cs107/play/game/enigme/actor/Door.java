package ch.epfl.cs107.play.game.enigme.actor;

import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.AreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Canvas;

public class Door extends AreaEntity {
		private String destinationArea;
		private DiscreteCoordinates coordinatesAtDestination;
		List<DiscreteCoordinates> position;
		
		
		public Door(Area area, String areaToGo, DiscreteCoordinates coordinatesToGo, 
				Orientation orientation, DiscreteCoordinates positionOfMainCell, List<DiscreteCoordinates> positionsOfOtherCells) {
			super(area, orientation, positionOfMainCell);
			destinationArea = areaToGo;
			coordinatesAtDestination = coordinatesToGo;
			position = positionsOfOtherCells;
			position.add(positionOfMainCell);
			
		}


		@Override
		public List<DiscreteCoordinates> getCurrentCells() {
			// TODO Auto-generated method stub
			return position;
		}


		@Override
		public boolean takeCellSpace() {
			// TODO Auto-generated method stub
			return true;
		}


		@Override
		public boolean isViewInteractable() {
			// TODO Auto-generated method stub
			return false;
		}


		@Override
		public boolean isCellInteractable() {
			// TODO Auto-generated method stub
			return true;
		}


		@Override
		public void draw(Canvas canvas) {
			// TODO Auto-generated method stub
			this.draw(canvas);
		}
		
		public String getDestinationArea() {
			return destinationArea;
		}
		
		public DiscreteCoordinates getCoordinatesAtDestination() {
			return coordinatesAtDestination;
		}
}
