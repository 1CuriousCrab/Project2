package ch.epfl.cs107.play.game.enigme;

import java.util.List;

import ch.epfl.cs107.play.game.areagame.AreaBehavior;
import ch.epfl.cs107.play.game.areagame.AreaBehavior.Cell;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Window;

public class Demo_2_Behavior extends AreaBehavior {
	
	public Demo_2_Behavior(Window window, String fileName) {
		
		super(window, fileName);
		
		for (int i = 0; i < getBehaviorMap().getWidth(); ++i) {
			for (int j = 0; j < getBehaviorMap().getHeight(); ++j) {
				Demo2CellType cellType = Demo2CellType.toType(getBehaviorMap().getRGB(getHeight() -1-j, i)) ;
				setCell(j, i, new Demo_2_Cell(i, j, cellType));
			}
		}
		
	}
	
//    
//    public Demo_2_Cell getCurrentCellPosition(DiscreteCoordinates coordinates) {
//    	return cells[(int) coordinates.toVector().getY()][(int) coordinates.toVector().getX()];
//    }
	
	
	public enum Demo2CellType {
		NULL(0),
		WALL(-16777216), //RGB code of black 
		DOOR(-65536), //RGB code of red 
		WATER(-16776961), //RGB code of blue 
		INDOOR_WALKABLE(-1),
		OUTDOOR_WALKABLE(-14112955) ;
		
		
		final int type ;
		
		Demo2CellType (int type) {
			this.type = type ;
			}
		
		static Demo2CellType toType(int type) {
			switch(type) {
				case -16777216 : 
					return WALL;
				case -65536 : 
					return DOOR;
				case -16776961 :
					return WATER;
				case -1 : 
					return INDOOR_WALKABLE;
				case -14112955 :
					return OUTDOOR_WALKABLE;
				default :
					return NULL;
			}
		}
	}
	
	
	public class Demo_2_Cell extends Cell {
		
		private Demo2CellType type;
		
		private Demo_2_Cell(int x, int y, Demo2CellType type) {
			super(x, y);
			this.type = type;
		}
		
		private Demo_2_Cell(DiscreteCoordinates coordinates, Demo2CellType type) {
			super(coordinates);
			this.type = type;
		}

		@Override
		public List<DiscreteCoordinates> getCurrentCells() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean takeCellSpace() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isViewInteractable() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isCellInteractable() {
			// TODO Auto-generated method stub
			return true;
		}
		
		@Override
		protected boolean canEnter(Interactable entity) {
			if (type == Demo2CellType.WALL || type == Demo2CellType.NULL) {
				return false;
			} else {
				return true;
			}
		}
		
		@Override
		protected boolean canLeave(Interactable entity) {
			return true;
		}
		
		public Demo2CellType getType() {
			return type;
		}
	}
}
