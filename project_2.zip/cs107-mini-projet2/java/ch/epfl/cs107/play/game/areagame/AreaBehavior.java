package ch.epfl.cs107.play.game.areagame;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import ch.epfl.cs107.play.game.actor.Actor;
import ch.epfl.cs107.play.game.areagame.actor.Interactable;
import ch.epfl.cs107.play.game.areagame.io.ResourcePath;
import ch.epfl.cs107.play.game.enigme.Demo_2;
import ch.epfl.cs107.play.game.enigme.Demo_2_Behavior.Demo2CellType;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Image;
import ch.epfl.cs107.play.window.Window;

/**
 * AreaBehavior manages a map of Cells.
 */
public abstract class AreaBehavior
{

    /// The behavior is an Image of size height x width
    // TODO implements me #PROJECT #TUTO
	private final Image behaviorMap;
	private final int width;
	private final int height;
	private final Cell[][] cells;
    /**
     * Default AreaBehavior Constructor
     * @param window (Window): graphic context, not null
     * @param fileName (String): name of the file containing the behavior image, not null
     */
    public AreaBehavior(Window window, String fileName){
        // TODO implements me #PROJECT #TUTO
    	behaviorMap = window.getImage(ResourcePath.getBehaviors(fileName), null, false);
    	width = behaviorMap.getWidth();
    	height = behaviorMap.getHeight();
    	cells = new Cell[width][height];
    }
    
    public Cell[][] getCell() {
    	return cells;
    }

    public int getWidth() {
    	return width;
    }
    
    public int getHeight() {
    	return height;
    }
    
    public Image getBehaviorMap() {
    	return behaviorMap;
    }
    
    public List<DiscreteCoordinates> getCurrentCells(DiscreteCoordinates position)	{
    	List<DiscreteCoordinates> positionOfCell = new ArrayList<>();
    	positionOfCell.add(position);
    	return positionOfCell;
    }
    
    public boolean canLeave(Interactable entity, List<DiscreteCoordinates> coordinates) {
    	boolean autorisation = true;
    	for(int i = 0; i < coordinates.size(); ++i) {
    		if (!cells[(int) coordinates.get(i).toVector().getY()][(int) coordinates.get(i).toVector().getX()].canLeave(entity)) {
    			autorisation = false;
    		}
    	}
    	return autorisation;
    }
    
    public boolean canEnter(Interactable entity, List<DiscreteCoordinates> coordinates) {
    	boolean autorisation = true;
    	for(int i = 0; i < coordinates.size(); ++i) {
    		if (!cells[coordinates.get(i).y][ coordinates.get(i).x].canEnter(entity)||isingrid(coordinates.get(i))) {
    			autorisation = false;
    		}
    	}
    	return autorisation;
    }
    public boolean isingrid(DiscreteCoordinates coordinates) {
    	if(0 <= coordinates.x && coordinates.x <= cells.length && 0 <= coordinates.y && coordinates.y <= cells[0].length) {
    		return true;
    		}
    	else {
    		return false;
    	}
    }
    
    public Cell getCurrentCellPosition(DiscreteCoordinates coordinates) {
    	return cells[(int) coordinates.toVector().getY()][(int) coordinates.toVector().getX()];
    }
    
    protected void leave(Interactable entity, List<DiscreteCoordinates> coordinates) {
    	if (canLeave(entity, coordinates)) {
    		for (int i = 0; i < coordinates.size(); ++i) {
    			getCurrentCellPosition(coordinates.get(i)).leave(entity);
    		}
    		
    	}
    }
    
    protected void enter(Interactable entity, List<DiscreteCoordinates> coordinates) {
    	if (canEnter(entity, coordinates)) {
    		for (int i = 0; i < coordinates.size(); ++i) {
    			getCurrentCellPosition(coordinates.get(i)).enter(entity);
    		}
    	}
    }
    
    public final void setCell(int ligne, int colonne, Cell cell) {
    	cells[ligne][colonne] = cell;
    }

   
    

    
	    // TODO implements me #PROJECT #TUTO
	    public abstract class Cell implements Interactable{
	    	private DiscreteCoordinates position;
	    	private Set<Actor> actorsInCells = new HashSet<>();
	    	private Set<Interactable> interactable = new HashSet<>();
	    	
	    	public Cell(int x, int y) {
	    		position = new DiscreteCoordinates(x, y);
	    	}
	    	
	    	public Cell(DiscreteCoordinates position) {
	    		this.position = position;
	    	}
	    	
	    	private void enter(Interactable entity) {
	    		if (canEnter(entity)) {
	    			interactable.add(entity);
	    		}
	    	}
	    	
	    	private void leave(Interactable entity) {
	    		if(canLeave(entity)) {
	    			interactable.remove(entity);
	    		}
	    	}
	    	
	    	protected  abstract boolean canEnter(Interactable entity);
	    	
	    	protected abstract boolean canLeave(Interactable entity);
	    }
    
    
}