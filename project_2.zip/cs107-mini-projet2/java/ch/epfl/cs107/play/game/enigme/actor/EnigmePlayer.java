package ch.epfl.cs107.play.game.enigme.actor;

import java.util.Collections;
import java.util.List;

import ch.epfl.cs107.play.game.areagame.Area;
import ch.epfl.cs107.play.game.areagame.actor.Interactor;
import ch.epfl.cs107.play.game.areagame.actor.MovableAreaEntity;
import ch.epfl.cs107.play.game.areagame.actor.Orientation;
import ch.epfl.cs107.play.game.areagame.actor.Sprite;
import ch.epfl.cs107.play.math.DiscreteCoordinates;
import ch.epfl.cs107.play.window.Button;
import ch.epfl.cs107.play.window.Canvas;
import ch.epfl.cs107.play.window.Keyboard;

public class EnigmePlayer extends MovableAreaEntity implements Interactor {
	
	private Sprite enigmePlayer;
	private final static int ANIMATION_DURATION = 8 ;
	private Door doorPassed;
	public boolean isPassingDoor = false;
	
	public EnigmePlayer(Area area , Orientation orientation , DiscreteCoordinates coordinates) {
		super(area, orientation, coordinates);
		enigmePlayer = new Sprite("ghost.1", 1, 1.f,this) ;
		
	}
	
	public EnigmePlayer(Area area , DiscreteCoordinates coordinates) {
		this(area, Orientation.DOWN, coordinates);
	}

	@Override
	public boolean takeCellSpace() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isViewInteractable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCellInteractable() {
		// TODO Auto-generated method stub
		return true;
	}
	
	@Override
	public List <DiscreteCoordinates > getCurrentCells() {
		return Collections.singletonList(getCurrentMainCellCoordinates()) ;
	}
	
	public void enterArea(Area area , DiscreteCoordinates position) {
		area.registerActor(this);
		this.setCurrentPosition(position.toVector());
		this.resetMotion();
	}
	
	public void leaveArea(Area area) {
		area.unregisterActor(this);
	}
	
	public void setSpecified(boolean value) {
		
	}
	
	public void update() {
		Keyboard keyboard = getOwnerArea().getKeyboard();
		Button left = keyboard.get(Keyboard.LEFT);
		Button right = keyboard.get(Keyboard.RIGHT);
		Button up = keyboard.get(Keyboard.UP);
		Button down = keyboard.get(Keyboard.DOWN);
		if (left.isDown()) {
			if (getRealOrientation() == Orientation.LEFT) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.LEFT);
			}
		}
		
		if (right.isDown()) {
			if (getRealOrientation() == Orientation.RIGHT) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.RIGHT);
			}
		}
		
		if (up.isDown()) {
			if (getRealOrientation() == Orientation.UP) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.UP);
			}
		}
		
		if (down.isDown()) {
			if (getRealOrientation() == Orientation.DOWN) {
				move(ANIMATION_DURATION);
			} else {
				setOrientation(Orientation.DOWN);
			}
		}
		isPassingDoor = false;
	}

	@Override
	public void draw(Canvas canvas) {
		// TODO Auto-generated method stub
		enigmePlayer.draw(canvas);
		
	}
	
	public void setIsPassingDoor(Door door) {
		isPassingDoor = true;
		doorPassed = door;
	}
	
	public Door passedDoor() {
		return doorPassed;
	}

	@Override
	public List<DiscreteCoordinates> getFieldOfViewCells() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean wantsCellInteraction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean wantsViewInteraction() {
		// TODO Auto-generated method stub
		return false;
	}
	
}

